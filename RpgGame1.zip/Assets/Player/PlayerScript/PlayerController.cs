using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 1f;
    public float collisionOffset = 0.05f;
    public ContactFilter2D movenentFilter;
    Vector2 movenentInput;
    Rigidbody2D rb;

    List<RaycastHit2D> castCollisions = new List<RaycastHit2D>();
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if(movenentInput != Vector2.zero)
        {
            bool success = TrMove(movenentInput);

            if(!success){
                success = TrMove(new Vector2(movenentInput.x,0));

                if(!success){
                    success = TrMove(new Vector2(0, movenentInput.y));
                }
            }
        }
    }
    private bool TrMove(Vector2 direction)
    {
        int count = rb.Cast(movenentInput, 
            movenentFilter, 
            castCollisions, 
            moveSpeed * Time.fixedDeltaTime * collisionOffset);
        if (count == 0)
        {
            rb.MovePosition(rb.position + movenentInput * moveSpeed * Time.fixedDeltaTime);
            return true;
        }
        else
        {
            return false;
        }
    }

    void OnMove(InputValue movenentValue)
    {
        movenentInput = movenentValue.Get<Vector2>();
    }   
}
